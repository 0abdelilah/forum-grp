package models

type Likes struct {
	Username   string
	Target_type string
	Target_id   int
	Value       int
}
