package models

type Error struct {
	MassageError string
	Errorstatus  int
}
