package models

type Category struct {
	Id       int
	Category string
	Selected string
}
